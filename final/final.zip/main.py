from final import *
print(exam)