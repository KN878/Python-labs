# Python 3.7.4
from reflect import  reflect


@reflect
def f():
    print("nothing")


f()
